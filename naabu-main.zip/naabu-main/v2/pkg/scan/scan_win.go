//go:build windowz

package scan
