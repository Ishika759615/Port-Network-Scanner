package scan

// todo: temporary disabling the test as the third-party service is not working
// func TestWhatsMyIP(t *testing.T) {
// 	externalIp, err := WhatsMyIP()
// 	assert.Nil(t, err)
// 	assert.NotEmpty(t, externalIp)
// }
